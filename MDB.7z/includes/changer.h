/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   changer.h
 * Author: Isaac
 *
 * Created on 30 de abril de 2018, 11:18 AM
 */

#ifndef CHANGER_H
#define CHANGER_H

#include "MDBDevice.h"

#define     CHANGER_RESET   0x08
#define     CHANGER_SETUP   0X09
#define     CHANGER_POLL    0X0B

struct Data {
    char data[36];
    char dataLen;
};

class Changer : private MDBDevice {
public:
    
    int stateMachineInit();
    
    Changer();
    int initializeChanger();
    int reset();
    int setup();
    int poll();
    int ID();
private:
    char cmd;
    struct Data VMC;
    struct Data CoinChanger;
};

#endif /* CHANGER_H */

Changer::Changer() {

}

int Changer::initializeChanger() {
    return MDBDevice::initializeMDB(1, 4);
}

int Changer::reset() {
    cmd = 0x08;
    VMC.dataLen = 0;
     printf("RESET\n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("\n reset: ACK \n");
        return 0;
    } else {
        printf("\n reset failed \n");
        return 1;
    }
}

int Changer::setup() {
    cmd = 0x09;
    VMC.dataLen = 0;
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 24) {
        printf("\n setup: ACK \n");
        return 0;
    } else {
        printf("\n setup failed \n");
        return -1;
    }
}

int Changer::poll(){
    cmd = 0x0B;
    VMC.dataLen = 0;
     printf("POLL \n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
   
    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("poll: ACK \n");
        return 0;
    } else if (CoinChanger.dataLen == 2 && CoinChanger.data[0] ==  CoinChanger.data[1]) {
        MDBDevice::sendACK();
        printf("\n poll: 0b 0b \n");
        return 1;
    } else if (CoinChanger.dataLen == 2 && CoinChanger.data[0] == 0 && CoinChanger.data[1] == 0) {
        printf("\n poll: 0 0 \n");
        return 2;
    } else if (CoinChanger.dataLen == 17) {
        printf("\n poll: report Change \n");
        return 3;
    } else
        return -1;
}

int Changer::ID() {
    cmd = 0x0f;
    VMC.dataLen = 1;
    VMC.data[0] = 00;
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("\n poll: ACK \n");
        return 0;
    } else if (CoinChanger.dataLen == 2 && CoinChanger.data[0] == 0 && CoinChanger.data[1] == 0) {
        printf("\n poll: JUST RESET \n");
        return 1;
    } else if (CoinChanger.dataLen == 17) {
        printf("\n poll: report Change \n");
        return 2;
    } else
        return -1;
}

int Changer::stateMachineInit(){
    static char state = CHANGER_RESET;
    int result = 0;
    
    switch(state){
        case CHANGER_RESET:
            result = reset();
            if(result == 0){
                state = CHANGER_POLL;
            }else{
                state = CHANGER_RESET;
            }            
            break;
        case CHANGER_POLL:
            result = poll();
            if(result == 0){
                state = CHANGER_POLL;
            }else{
                state = CHANGER_POLL;
            } 
            
    }
    return 0;
}