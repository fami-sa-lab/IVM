/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Isaac
 *
 * Created on 24 de abril de 2018, 11:39 AM
 */

#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include "includes/changer.h"


using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int result = 0;
    Changer changer;

    if (changer.initializeChanger() == 0) {
        
        while(1){
            changer.stateMachineInit();
            usleep(50000);
            usleep(50000);        
        }
        /*do {
            result = changer.reset();
            usleep(50000);
        } while (result != 0);
        do {
            result = changer.poll();
            usleep(50000);
        } while (result != 1);
        do {
            result = changer.reset();
            usleep(50000);
        } while (result != 0);
        do {
            result = changer.poll();
            usleep(50000);
        } while (result != 0);
        changer.ID();
        usleep(50000);
        usleep(50000);
        changer.setup();*/
    }

    return 0;
}

