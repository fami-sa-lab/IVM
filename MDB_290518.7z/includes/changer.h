/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   changer.h
 * Author: Isaac
 *
 * Created on 30 de abril de 2018, 11:18 AM
 */

#ifndef CHANGER_H
#define CHANGER_H

#include "MDBDevice.h"
#include <stdlib.h>
#include <cstdio>
#include <stdint-gcc.h>

#define     CHANGER_RESET   0x08
#define     CHANGER_SETUP   0X09
#define     CHANGER_TUBE_STATUS     0X0A
#define     CHANGER_POLL    0X0B
#define     CHANGER_COIN_TYPE   0x0C
#define     CHANGER_EXPANSION_ID    0x0F

struct Data {//structura para manejar datos de VMC y Changer
    char data[36];
    char dataLen;
};

struct Setup_s {
    char changerFeatureLevel;
    int country;
    char coinScalingFactor;
    char decimalPlaces;
    int coinTypeRouting;
    char coinTypeCredit[16];
};

struct Id_s {
    char manufacturerCode[4];
    char serialNumber[13];
    char modelNumber[13];
    char softwareVersion[2];
    char optionalFeatures[4];
};

struct TubeStatus_s {
    int tubeFullStatus;
    char tubeStatus[16];
};

union CoinEnable_u {

    struct {
        char coinEn15 : 1;
        char coinEn14 : 1;
        char coinEn13 : 1;
        char coinEn12 : 1;
        char coinEn11 : 1;
        char coinEn10 : 1;
        char coinEn9 : 1;
        char coinEn8 : 1;
        char coinEn7 : 1;
        char coinEn6 : 1;
        char coinEn5 : 1;
        char coinEn4 : 1;
        char coinEn3 : 1;
        char coinEn2 : 1;
        char coinEn1 : 1;
        char coinEn0 : 1;
    };

    struct {
        char high;
        char low;
    };
    uint16_t coinEnable;
};

union ManualDispense_u {

    struct {
        char manualDispense15 : 1;
        char manualDispense14 : 1;
        char manualDispense13 : 1;
        char manualDispense12 : 1;
        char manualDispense11 : 1;
        char manualDispense10 : 1;
        char manualDispense9 : 1;
        char manualDispense8 : 1;
        char manualDispense7 : 1;
        char manualDispense6 : 1;
        char manualDispense5 : 1;
        char manualDispense4 : 1;
        char manualDispense3 : 1;
        char manualDispense2 : 1;
        char manualDispense1 : 1;
        char manualDispense0 : 1;
    };

    struct {
        char high;
        char low;
    };
    uint16_t manualDispense;
};

struct CoinType_s {
    CoinEnable_u CoinEnable;
    ManualDispense_u ManualDispense;
};

//union CoinTypeRouting_u{

//}coinTypeRouting;

class Changer : private MDBDevice {
public:

    int stateMachineInit();

    Changer();
    int initializeChanger();
    int reset();
    int setup();
    int poll();
    int coinType();
    int ID();
    int tubeStatus();
private:
    int setupResponseProcess();
    int IdResponseProcess();
    int tubeStatusResponseProcess();
    int setCoinType();
    char cmd;
    struct Data VMC;
    struct Data CoinChanger;
    Setup_s Setup;
    Id_s Id;
    TubeStatus_s TubeStatus;
    CoinType_s CoinType;
};

#endif /* CHANGER_H */

Changer::Changer() {

}

int Changer::initializeChanger() {
    return MDBDevice::initializeMDB(3, 1);
}

int Changer::reset() {
    cmd = 0x08;
    VMC.dataLen = 0;
    printf("RESET\n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("\n reset: ACK \n");
        return 0;
    } else {
        printf("\n reset failed \n");
        return 1;
    }
}

int Changer::setup() {
    cmd = 0x09;
    VMC.dataLen = 0;
    printf("SETUP\n");

    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 24) {
        MDBDevice::sendACK();
        printf("\n setup: OK \n");
        // this -> Setup.coinTypeRouting.CTR.high = CoinChanger.data[5];
        // this -> Setup.coinTypeRouting.CTR.low = CoinChanger.data[6];
        //this -> Setup.coinTypeRouting = (CoinChanger.data[5] << 8) & CoinChanger.data[6];
        setupResponseProcess();
        return 0;
    } else {
        printf("\n setup failed \n");
        return -1;
    }
}

int Changer::tubeStatus() {
    cmd = CHANGER_TUBE_STATUS;
    VMC.dataLen = 0;
    printf("SETUP\n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 19) {
        MDBDevice::sendACK();
        printf("\n Tube Status: OK \n");
        tubeStatusResponseProcess();
        return 0;
    } else {
        printf("\n Tube Status failed \n");
        return -1;
    }
}

int Changer::poll() {
    cmd = 0x0B;
    VMC.dataLen = 0;
    printf("POLL \n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);

    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("poll: ACK \n");
        return 0;
    } else if (CoinChanger.dataLen == 2 && CoinChanger.data[0] == CoinChanger.data[1]) {
        MDBDevice::sendACK();
        printf("\n poll: 0b 0b \n");
        return 1;
    } else if (CoinChanger.dataLen == 2 && CoinChanger.data[0] == 0 && CoinChanger.data[1] == 0) {
        printf("\n poll: 0 0 \n");
        return 2;
    } else if (CoinChanger.dataLen == 17) {
        printf("\n poll: report Change \n");
        return 3;
    } else
        return -1;
}

int Changer::coinType() {
    cmd = CHANGER_COIN_TYPE;
    setCoinType();
    VMC.dataLen = 4;
    VMC.data[0] = 0x00;
    VMC.data[1] = 0x1d;
    VMC.data[2] = 0x00;
    VMC.data[3] = 0x1d;

//        VMC.data[0]= CoinType.CoinEnable.high;
//        VMC.data[1]= CoinType.CoinEnable.low;
//        VMC.data[2]= CoinType.ManualDispense.high;
//        VMC.data[3]=  CoinType.ManualDispense.low;                  

    printf("Coin Type\n");
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);

    if (CoinChanger.dataLen == 1 && CoinChanger.data[0] == 0) {
        printf("Coin Type: ACK \n");
        return 0;
    } else
        return -1;
}

int Changer::ID() {
    cmd = 0x0f;
    VMC.dataLen = 1;
    VMC.data[0] = 00;
    CoinChanger.dataLen = MDBDevice::sendCommand(cmd, VMC.data, VMC.dataLen, CoinChanger.data);
    if (CoinChanger.dataLen == 34) {
        MDBDevice::sendACK();
        printf("\n ID: OK \n");
        IdResponseProcess();
        return 0;
    } else
        printf("\n ID failed \n");
    return -1;
}

int Changer::stateMachineInit() {
    static char state = CHANGER_RESET;
    int result = 0;

    switch (state) {
        case CHANGER_RESET:
            result = reset();
            if (result == 0) {
                state = CHANGER_POLL;
            } else {
                state = CHANGER_RESET;
            }
            break;
        case CHANGER_POLL:
            result = poll();
            if (result == 0) {
                state = CHANGER_SETUP;
            } else {
                state = CHANGER_POLL;
            }
            break;
        case CHANGER_SETUP:
            result = setup();
            if (result == 0) {
                state = CHANGER_EXPANSION_ID;
            } else {
                state = CHANGER_SETUP;
            }
            break;
        case CHANGER_EXPANSION_ID:
            result = ID();
            if (result == 0) {
                state = CHANGER_TUBE_STATUS;
            } else {
                state = CHANGER_EXPANSION_ID;
            }
            break;
        case CHANGER_TUBE_STATUS:
            result = tubeStatus();
            if (result == 0) {
                state = CHANGER_COIN_TYPE;
            } else {
                state = CHANGER_TUBE_STATUS;
            }
            break;
        case CHANGER_COIN_TYPE:
            result = coinType();
            if (result == 0) {
                state = 3;
            } else {
                state = CHANGER_COIN_TYPE;
            }
            break;
        case 3:
            result = poll();
            if (result == 0) {

                state = 3;
            } else {
                state = 3;
            }
            break;

    }
    return 0;
}

int Changer::setupResponseProcess() {
    Setup.changerFeatureLevel = CoinChanger.data[0];

    Setup.country = CoinChanger.data[1];
    Setup.country <<= 8;
    Setup.country |= CoinChanger.data[2];

    Setup.coinScalingFactor = CoinChanger.data[3];

    Setup.decimalPlaces = CoinChanger.data[4];

    Setup.coinTypeRouting = CoinChanger.data[5];
    Setup.coinTypeRouting <<= 8;
    Setup.coinTypeRouting = CoinChanger.data[6];

    for (int i = 0; i < 16; i++) {
        Setup.coinTypeCredit[i] = CoinChanger.data[7 + i];
    }

    printf("Feature level: %c\n", Setup.changerFeatureLevel);
    printf("Country: %d\n", Setup.country);
    printf("Coin Scaling Factor: %c\n", Setup.coinScalingFactor);
    printf("Decimal places: %c\n", Setup.decimalPlaces);
    printf("\n");
    printf("num\tCoin Type Routing\tCoin Type Credit\n");
    for (int i = 0; i < 16; i++) {
        printf("%d\t\t%d\t\t%d\n", i, (Setup.coinTypeRouting >> i)&1, (int*) Setup.coinTypeCredit[i]);
    }
    printf("\n");
    return 0;
}

int Changer::IdResponseProcess() {

    Id.manufacturerCode[0] = CoinChanger.data[0];
    Id.manufacturerCode[1] = CoinChanger.data[1];
    Id.manufacturerCode[2] = CoinChanger.data[2];
    Id.manufacturerCode[3] = 0;

    for (int i = 0; i < 12; i++) {
        Id.serialNumber[i] = CoinChanger.data[i + 3];
    }
    Id.serialNumber[12] = 0;
    for (int i = 0; i < 12; i++) {
        Id.modelNumber[i] = CoinChanger.data[i + 15];
    }
    Id.modelNumber[12] = 0;

    Id.softwareVersion[0] = CoinChanger.data[27];
    Id.softwareVersion[1] = CoinChanger.data[28];

    Id.optionalFeatures[0] = CoinChanger.data[29];
    Id.optionalFeatures[1] = CoinChanger.data[30];
    Id.optionalFeatures[2] = CoinChanger.data[31];
    Id.optionalFeatures[3] = CoinChanger.data[32];

    printf("Manufacturer Code: %s\n", Id.manufacturerCode);
    printf("Serial Number: %s\n", Id.serialNumber);
    printf("Model number: %s\n", Id.modelNumber);
    printf("Software version: %2x%2x\n", (int*) Id.softwareVersion[0], (int*) Id.softwareVersion[1]);
    printf("\n\n");
    return 0;
}

int Changer::tubeStatusResponseProcess() {
    TubeStatus.tubeFullStatus = CoinChanger.data[0];
    TubeStatus.tubeFullStatus <<= 8;
    TubeStatus.tubeFullStatus = CoinChanger.data[1];

    for (int i = 0; i < 16; i++) {
        TubeStatus.tubeStatus[i] = CoinChanger.data[2 + i];
    }

    printf("tube No.\tFull?\tStatus\n");
    for (int i = 0; i < 16; i++) {
        printf("%d \t\t%d\t\t%d\n", i, (TubeStatus.tubeFullStatus >> i)&1, (int*) TubeStatus.tubeStatus[i]);
    }
    printf("\n\n");
}

int Changer::setCoinType() {
    CoinType.CoinEnable.coinEnable = 0;

    CoinType.CoinEnable.coinEn0 = 1;
    CoinType.CoinEnable.coinEn2 = 1;
    CoinType.CoinEnable.coinEn3 = 1;
    CoinType.CoinEnable.coinEn4 = 1;

    CoinType.ManualDispense.manualDispense = 0;

    CoinType.ManualDispense.manualDispense0 = 1;
    CoinType.ManualDispense.manualDispense2 = 1;
    CoinType.ManualDispense.manualDispense3 = 1;
    CoinType.ManualDispense.manualDispense4 = 1;

    return 0;
}