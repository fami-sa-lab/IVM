/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   VendingMachineController.h
 * Author: Isaac
 *
 * Created on 1 de junio de 2018, 12:51 PM
 */

#ifndef VENDINGMACHINECONTROLLER_H
#define VENDINGMACHINECONTROLLER_H

#include "changer.h"
#include <string.h>
#include "GPIO.h"
#include <time.h>
#include <iostream>
//#include "mdbBus.h"

#define DEBUG_VMC   "--debug_VMC"

//VMC FSM
#define INITIALIZE  0
#define DETECT_COIN 1
#define DISPATCH    2
#define ENABLE      3

//DETECT COIN FSM
#define CREDIT      0
#define INHIBIT     1

#define TRANSACTION_COMPLETE 1

struct item_s {
    char amount; //cantidad de articulos que se venderán
    char name[8][25]; //nombres de articulos
    int price[8]; //precios
    int highestPrice;
    int available[8]; //disponible para venta
};

class VendingMachineController : protected Changer, protected BillValidator {
public:
    VendingMachineController(int argc, char** argv);
    int searchMoney();
    int pollButtons();
    int getCredit();
    int stateMachineVSM(int pSelectedItem);
private:
    int credit;
    int escrow;
    int change;
    int charge;

    int buttons[5];
    int detectCoinSequence(int pSelectedItem);
    int updateCredit();
    int readButton(char pGpio);
    item_s Items;
    int vmcDebugFlag;
 

};
#endif /* VENDINGMACHINECONTROLLER_H */

VendingMachineController::VendingMachineController(int argc, char** argv) {
    int mdb_fp;
       
    vmcDebugFlag = 0;
    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            if (strcmp(argv[i], "--debug_VMC") == 0) {
 //               cout << "VMC debug on" << endl;
                vmcDebugFlag = 1;
            }
        }
    }
     mdb_fp = initializeMDB(argc,argv,1);
    Changer::config(mdb_fp,argc, argv);
    BillValidator::config(mdb_fp,argc,argv);
    
    Items.amount = 2;
    Items.highestPrice = 2200;
    
    strncpy(Items.name[0], "5Kg Hielo la Torre", 25);
    Items.price[0] = 700;
    Items.available[0] = 1;
    
    strncpy(Items.name[1], "7Kg Hielo la Torre", 25);
    Items.price[1] = 2200;
    Items.available[1] = 1;
    
    buttons[0] = 61;
    buttons[1] = 65;
    buttons[2] = 46;
    buttons[3] = 26;
    buttons[4] = 44;
    
    credit = 0;
}

int VendingMachineController::updateCredit() {
    struct PollResponse result;
    result = Changer::poll();
    if (result.type == COINS_DEPOSITED && result.coinType>= 0) {
        credit += Changer::coinTypeTubeValue[result.coinType][VALUE];
    }
    result = BillValidator::poll();
    if (result.type == BV_POLL_DEPOSITED && result.coinType >= 0) {
        credit += BillValidator::billTypeValue[result.coinType];
        if(result.routing == ESCROW_POSITION){
            escrow = BillValidator::billTypeValue[result.coinType];
        }
    }
    return credit;
}

int VendingMachineController::readButton(char pGpio) {
    GPIO gpio(pGpio);
    return gpio.readValue();
}

int VendingMachineController::pollButtons() {
    char counter;
    int state;
    for (int i = 0; i < Items.amount; i++) {
        do {
            state = readButton(buttons[i]);
            if (state == 0) {
                counter++;
            }
            if (counter >= 3) {
                return i;
            }
        } while (state == 0);
    }
    return -1;
}

int VendingMachineController::stateMachineVSM(int pSelectedItem) {
    static char state = INITIALIZE;
    int result;
    int resultBill;
    switch (state) {
        case INITIALIZE:

            result = Changer::initializeSequence();
            resultBill = BillValidator::initializeSequence();
            
            if (result && resultBill) {
                state = DETECT_COIN;
            } else {
                state = INITIALIZE;
            }
            break;


        case DETECT_COIN:
            result = detectCoinSequence(pSelectedItem);
            if (result) {
                state = DISPATCH;
            } else {
                state = DETECT_COIN;
            }
            break;
            
        case DISPATCH:       
            if(escrow > 0){
                
            }
            if(credit > charge){
                change = credit -charge;
                //Changer::tubeStatus();
                //Changer::change(credit - charge);
                result = Changer::giveChangeSequence(change);
                if(result == 1){ //termina de dar cambio
                    state = ENABLE;
                    return DONE;//1 cuando vendió exitosamente
                }else{
                    state = DISPATCH;
                }
            }else{
                state = ENABLE;
                return 1;
            }
            
            break;
        case ENABLE:
            credit = 0;
            charge = 0;
            change = 0; 
            escrow = 0;
            Changer::coinType(ACCEPT);
            BillValidator::billType(ACCEPT);
            state = DETECT_COIN;
            break;
                    
    }
    return 0;
}

int VendingMachineController::detectCoinSequence(int pSelectedItem) {
    static int state = CREDIT;
    static int creditAux = 0;
    switch (state) {
        case CREDIT:

            updateCredit(); //poll

            if ((Changer::isInhibited()) && (pSelectedItem >= 0)){ //verificar que haya producto
                charge = Items.price[pSelectedItem];
                return 1;
            }
            //Si entra una moneda
            if (creditAux != credit) {
                creditAux = credit;
                if (this -> credit >= this -> Items.highestPrice) { //si se ha ingresado suficiente dinero
                    state = INHIBIT; //inhibe aceptador
                }
                if (vmcDebugFlag) {
                    printf("Credit : %d \n", this -> credit); //muestra en pantalla crédito ingresado
                }
            }

            if (pSelectedItem >= 0) {//si se selecciono un articulo
                charge = Items.price[pSelectedItem];
                if (this -> credit >= charge) {
                    state = INHIBIT;
                }
            }

            break;
        case INHIBIT:
            Changer::coinType(NO_ACCEPT);
            BillValidator::billType(NO_ACCEPT);
            if (vmcDebugFlag) {
                printf("INHIBIT COINS\n");
            }
            state = CREDIT;
            break;

    }
    return 0;

}