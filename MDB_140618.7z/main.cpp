/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Isaac
 *
 * Created on 24 de abril de 2018, 11:39 AM
 */

#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>

#include "includes/VendingMachineController.h"

#define __100MS     CLOCKS_PER_SEC/10 

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    int selectedItem = -1;
    //int *item = &selectedItem; //apuntador a articulo seleccionado
    int result;
    int transaccion;
    
    clock_t anterior, actual;

    if (argc > 1) {
        for (int i = 1; i < argc; i++) {
            if (strncmp(argv[i], "help", 4) == 0) {
                cout << "--debug_MDB" << endl;
                cout << "--debug_Changer" << endl;
                cout << "--debug_VMC" << endl;
                return 0;
            }
        }
    }

    VendingMachineController Despachador(argc, argv); //constructor de despachador

    anterior = clock(); // tiempo inicial

    while (1) {
        actual = clock(); //tiempo inicial
        if ((actual - anterior) >= __100MS) { //cada 100ms envia comandos de VSM a periféricos
            anterior = actual; //guarda tiempo de último comado

            transaccion = Despachador.stateMachineVSM(selectedItem);
            if(transaccion == 1){
                selectedItem = -1;
            }
        }

        //poll buttons
            result = Despachador.pollButtons(); //guarda en result el boton presionado, que corresponderá al número de artículo
            if (result >= 0 && result != selectedItem) { //si result es mayor que cero
                selectedItem = result; //actualiza artículo seleccionado
                cout << "Boton " << selectedItem << " presionado." << endl;
            }
            //Actualiza pantalla;    
            
            
    }
    return 0;
}

